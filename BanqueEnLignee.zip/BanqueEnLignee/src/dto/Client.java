package dto;

import java.util.Date;

import dao.*;

/**
 * Classe CLIENT
 * @author Prisca -Hornela
 * @version 1.2
 * */

public class Client {
	public int getIdClient() {
		return idClient;
	}







	public void setIdClient(int idClient) {
		this.idClient = idClient;
	}







	public String getNomClient() {
		return nomClient;
	}







	public void setNomClient(String nomClient) {
		this.nomClient = nomClient;
	}







	public String getPrenomClient() {
		return prenomClient;
	}







	public void setPrenomClient(String prenomClient) {
		this.prenomClient = prenomClient;
	}







	public String getBirthdayClient() {
		return birthdayClient;
	}







	public void setBirthdayClient(String birthdayClient) {
		this.birthdayClient = birthdayClient;
	}







	public String getMailClient() {
		return mailClient;
	}







	public void setMailClient(String mailClient) {
		this.mailClient = mailClient;
	}







	public String getMdpClient() {
		return mdpClient;
	}







	public void setMdpClient(String mdpClient) {
		this.mdpClient = mdpClient;
	}







	/**
	 *identifiant
	 */
    private int idClient;
	/** 
	 * Name of the client 
	 */
	private String nomClient;
	/** 
	 * Surname of the client 
	 */
	private String prenomClient;
	/** 
	 * Date of birth of the client 
	 */
	private String birthdayClient;
	/**
	 * adresse email
	 */
	private String mailClient;	
	/**
	 * mot de passe Client
	 */
	private String mdpClient;
		
	

	/**
	 * Constructeur
	 * @param idClient 
	 * @param  nomClient
	 * @param adresseClient
	 * @param nomContact NOM_CONTACT 
	 */
	public Client(String nomClient, String prenomClient,String birthdayClient, String mailClient, String mdpClient) {
		
		this.nomClient = nomClient;
		this.prenomClient = prenomClient;
		this.birthdayClient = birthdayClient;
		this.mailClient = mailClient;
		this.mdpClient = mdpClient;
		
	}
	


		

	

	/**
	 * Red finition de la m thode toString permettant de d finir la traduction de l'objet en String
	 * pour l'affichage par exemple
	 */
/*	public String toString() {
		return " [Client: " +idClient  + " , " + nomClient
				+ ", " + adresseClient+  " ]";
	}*/
}

