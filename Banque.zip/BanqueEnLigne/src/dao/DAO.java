package dao;

public class DAO {

}
