package dto;

public class Client {

}
